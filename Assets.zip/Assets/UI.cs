﻿using UnityEngine;
using UnityEngine.UI;

using System.Collections;

public class UI : MonoBehaviour
{
    public GameObject player_script;
    public Vector3 position;
    public float px, py, pz;
    public string text;
    public int HP;
    public Text display_text;
    public int points = 0;
    void Start()
    {
        position = player_script.GetComponent<Transform>().position;
        px = position.x;
        py = position.y;
        pz = position.z;

        HP = player_script.GetComponent<PlayerScript>().HP;
    }

    void FixedUpdate()
    {
        HP = player_script.GetComponent<PlayerScript>().HP;

        position = player_script.GetComponent<Transform>().position;
        px = position.x;
        py = position.y;
        pz = position.z;

        //Debug.Log(string.Format("X: {0}\tY: {1}\tZ: {2}\tHP: {3}", px.ToString("0.00"), py.ToString("0.00"), pz.ToString("0.00"), HP));
        display_text.text = string.Format("HP: {0}\nX: {1}\tY: {2}\tZ: {3}", HP, px.ToString("0.00"), py.ToString("0.00"), pz.ToString("0.00") );

        if (HP<=0)
        {
            over();
        }
    }

    void over()
    {
        display_text.color = new Color(1, 0, 0, 1);
        display_text.transform.position = new Vector3(400, 250, 0);
        display_text.text = string.Format("GAME OVER!\nYou've earned {0} points", points);
    }
    
}
