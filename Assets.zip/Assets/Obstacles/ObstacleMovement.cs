﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleMovement : MonoBehaviour
{
    public Rigidbody rb;
    public float position_z;    // Aktualna pozycja na osi z
    public float start_z;       // Pozycja startowa na osi z
    public float end_z;         // Pozycja końcowa/docelowa na osi z
    public float velocity_z;    // Aktualna prędkość na osi z
    public float mspeed;        // Zadana prędkość poruszania się

    // Start is called before the first frame update
    void Start()
    {
        start_z = transform.position.z;
        end_z = start_z + 3;
        mspeed = 2000;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        position_z = transform.position.z;
        velocity_z = rb.velocity.z;

        //Debug.Log(string.Format("start: {0}\tposition: {1}\tend: {2}\tspeed: {3}", start_z, position_z, end_z, velocity_z));
        
        if (position_z <= start_z)
        {
            if (velocity_z == 0)
            {
                rb.AddForce(0, 0, mspeed * Time.deltaTime);
            }
            else
            {
                rb.velocity = Vector3.zero;
            }
        }
        if (position_z >= end_z)
        {
            if (velocity_z == 0)
            {
                rb.AddForce(0, 0, -mspeed * Time.deltaTime);
            }
            else
            {
                rb.velocity = Vector3.zero;
            }
        }


        // rb.AddForce(0, 0, -100 * Time.deltaTime);
        /*
        switch ( Input.GetKey() )
        {
            case "a":
                rb.AddForce(0, 0, -100 * Time.deltaTime);
                break;
            case "s":
                rb.AddForce(-100 * Time.deltaTime, 0, 0);
                break;
            case "w":
                rb.AddForce(100 * Time.deltaTime, 0, 0);
                break;
            case "d":
                rb.AddForce(0, 0, -100 * Time.deltaTime);
                break;
        }
        */
        /*
        if ( Input.GetKey("a") )
        {
            rb.AddForce(0, 0, -100 * Time.deltaTime);
        }
        if (Input.GetKey("d"))
        {
            rb.AddForce(0, 0, 100 * Time.deltaTime);
        }
        if (Input.GetKey("s"))
        {
            rb.AddForce(100 * Time.deltaTime, 0, 0 );
        }
        if (Input.GetKey("w"))
        {
            rb.AddForce(-100 * Time.deltaTime, 0, 0);
        }
        if (Input.GetKey("up"))
        {
            rb.AddForce(0, 100 * Time.deltaTime, 0);
        }
        if (Input.GetKey("down"))
        {
            rb.AddForce(0, -100 * Time.deltaTime, 0);
        }
        */
    }
}
