﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Obstacle_2_Movement : MonoBehaviour
{
    public Rigidbody rb;
    public bool left, right;
    public float position_x;    // Aktualna pozycja na osi x
    public float start_x;       // Pozycja startowa na osi x
    public float end_x;         // Pozycja końcowa/docelowa na osi x
    public float speed;        // Zadana prędkość poruszania się

    // Start is called before the first frame update
    void Start()
    {
        right = true;
        left = !right;
        start_x = (float)Math.Round(transform.position.x);
        end_x = start_x + 3;
        speed = 2;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        position_x = (float)Math.Round(transform.position.x);

        if (position_x == start_x)
        {
            right = true;
            left = false;
        }
        else
        if (position_x == end_x)
        {
            right = false;
            left = true;
        }

        if (right == true)
        {
            rb.velocity = new Vector3(speed, 0, 0);
        }
        else
        if (left == true)
        {
            rb.velocity = new Vector3(-speed, 0, 0);
        }


    }
}
