﻿using UnityEngine;
using System.Collections;

public class FollowPlayer : MonoBehaviour
{
    public Transform player;
    public Vector3 offset;
    public float old_pz, new_pz;
    public float move_z;
    public Vector3 movevec;

    void Start()
    {
        transform.position = player.position + offset;
        old_pz = player.position.z;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        new_pz = player.position.z;
        
        move_z = old_pz - new_pz;
        transform.Translate( 0, 0, - move_z, Space.World);
        
        //Debug.Log(string.Format("old_pz: {0}\tnew_pz: {1}\tmove: {2}", old_pz, new_pz, move_z));
        //transform.position = player.position + offset;
        old_pz = new_pz;
    }
}
