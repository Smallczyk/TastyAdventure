﻿using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    public bool hitFloor = false;
    public bool hitObstacle = false;

    void OnCollisionEnter ( Collision collisionInfo)
    {
        if (collisionInfo.collider.tag == "Floor")
        {
            hitFloor = true;
        }
        else
        {
            hitFloor = false;
        }

        if (collisionInfo.collider.tag == "Obstacle")
        {
            hitObstacle = true;
        }
        else
        {
            hitObstacle = false;
        }
    }
}
