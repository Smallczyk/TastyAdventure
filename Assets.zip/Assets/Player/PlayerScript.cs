﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;


public class PlayerScript : MonoBehaviour
{
    public Rigidbody rb;
    public int HP;
    public float px, py, pz;
    public float mforward = 1000f;
    public Vector3 old_pos;
    public Vector3 start_pos;
    public bool moving;

    public PlayerCollision collision;
    
    // Start is called before the first frame update
    void Start()
    {
        HP = 3;
        rb.mass = 3.66f;
        start_pos = transform.position;
        old_pos = start_pos;
    }
    
    

    // Update is called once per frame
    void FixedUpdate()
    {
        //  SEKCJA POZYCJI  \\

        px = transform.position.x;
        py = transform.position.y;
        pz = transform.position.z;

        if (old_pos != transform.position)
        {
            moving = true;
        }
        else 
        {
            moving = false;
            transform.position = new Vector3((float)Math.Round(px), py, (float)Math.Round(pz));
        }

        //Debug.Log(string.Format("hitFloor: {0}\thitObstacle: {1}", collision.hitFloor, collision.hitObstacle));
        //Debug.Log(string.Format("X: {0}\tY: {1}\tZ: {2}\tmoving: {3}", px, py, pz, moving));
        
        // SEKCJA KOLIZJI \\

        if (collision.hitObstacle == true)
        {
            collision.hitObstacle = false;
            HP -= 1;
            rb.velocity = Vector3.zero;
            transform.position = start_pos;
        }
        else
        if (py<=0)
        {
            HP -= 1;
            rb.velocity = Vector3.zero;
            transform.position = start_pos;
        }

        //  SEKCJA RUCHU \\

        if (moving == false && Input.GetKey("s"))
        {
            rb.AddForce(0, mforward * Time.deltaTime, -mforward * Time.deltaTime);
            moving = true;
        }
        if (moving == false && Input.GetKey("w"))
        {
            rb.AddForce(0, mforward * Time.deltaTime, mforward * Time.deltaTime);
            moving = true;
        }
        if (moving == false && Input.GetKey("a"))
        {
            rb.AddForce(-mforward * Time.deltaTime, mforward * Time.deltaTime, 0);
            moving = true;
        }
        if (moving == false && Input.GetKey("d"))
        {
            rb.AddForce(mforward * Time.deltaTime, mforward * Time.deltaTime, 0);
            moving = true;
        }

        old_pos = transform.position;
    }
}
