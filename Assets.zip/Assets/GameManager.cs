﻿using UnityEngine;

public class GameManager : MonoBehaviour
{
    public GameObject player_script;
    public int HP;
    public bool GAME_OVER;

    void Start()
    {
        HP = player_script.GetComponent<PlayerScript>().HP;
        GAME_OVER = false;
    }

    void FixedUpdate()
    {
        HP = player_script.GetComponent<PlayerScript>().HP;
    }

    void EndGame()
    {
        if (HP<=0)
        {
            GAME_OVER = true;
            Application.Quit();
        }
    }
}
